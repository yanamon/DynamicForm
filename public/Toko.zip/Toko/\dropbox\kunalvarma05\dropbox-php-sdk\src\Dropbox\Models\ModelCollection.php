<?php
namespace Kunnu\Dropbox\Models;

use Illuminate\Support\Collection;

/**
 * @link https://laravel.com/docs/5.2/collections
 */
class ModelCollection extends Collection
{
    //
}
