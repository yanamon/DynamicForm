<?php
namespace Kunnu\Dropbox\Models;

class PhotoMetadata extends MediaMetadata
{
}
