

<?php
    require_once "../dropbox/autoload.php"; 
    use Kunnu\Dropbox\DropboxFile; 
    use Kunnu\Dropbox\DropboxApp; 
    use Kunnu\Dropbox\Dropbox; 
    // while(true){
        try{    
            $app = new DropboxApp($app_key, $app_secret, $access_token); 
            $dropbox = new Dropbox($app); 
            
            foreach($syncs as $sync){
                $path = "/".$project_name."/".$sync["folder"]."/unsynchronized";
                $listFile = $dropbox->listFolder($path);
                $first_file_name = $listFile->getItems()->first()->getName();

                $file_download = $dropbox->download($path."/".$first_file_name);
                $file_content = json_decode($file_download->getContents(),true);

                $attributes = ""; 
                $values = "";
                foreach($sync['attribute'] as $i => $attr){
                    $attributes = $attributes.$attr;
                    if($i != count($sync['attribute'])-1) $attributes = $attributes.",";
                }
                foreach($file_content as $i => $data){
                    $values = $values.$data;
                    if($i != count($file_content)-1) $values = $values.", ";
                }
                $query = "INSERT INTO ".$sync["table"]."(".$attributes.") VALUES(".$values.")";
                $conn = new PDO("mysql:host=$server;dbname=$db", $user, $pass);
                $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
                $sql = $conn->prepare($query);
                $sql->execute();

                $move_path = $path = "/".$project_name."/".$sync["folder"]."/synchronized";
                $move = $dropbox->move($path."/".$first_file_name, $move_path."/".$first_file_name);
            }

            $result['message'] = "Connected to dropbox project: ".$project_name;
            echo($result['message']);


        }catch(Exception $e){   
            $result['message']  = "Connection failed: " . $e->getMessage();
            echo($result['message']);
        }

    // }
?>